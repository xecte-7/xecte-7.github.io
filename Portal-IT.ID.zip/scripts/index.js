// https://www.w3schools.com/w3css/w3css_slideshow.asp
// https://www.w3schools.com/w3css/tryit.asp?filename=tryw3css_slideshow_dots2

